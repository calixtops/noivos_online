import Head from 'next/head';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { motion } from 'framer-motion';
import { QRCodeSVG } from 'qrcode.react';
import gifts from '../../data/gifts.json'; // Criaremos este arquivo depois

const Presentes = () => {
  const pixCode = '00020101021226870014br.gov.bcb.pix2569qrcodes-pix.gerencianet.com.br/v2/9d36b84fc7e74bee9588e69aa92f9e9e520400005303986540812.005802BR5925Gerencianet Pagamentos6007Sao Paulo62360532ad156a3d3f3e4e3a3d3f3e4e3a3d3f3e4e3a3d6304FCE0';

  return (
    <div className="min-h-screen flex flex-col">
      <Head>
        <title>Lista de Presentes - Pedro & Geórgia</title>
      </Head>

      <Header />

      <main className="container mx-auto px-4 py-12 flex-grow">
        <motion.h1 
          className="text-4xl font-serif text-center text-rose-700 mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Nossa Lista de Presentes
        </motion.h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {gifts.map((gift, index) => (
            <motion.div 
              key={gift.id}
              className="bg-white rounded-lg shadow-lg overflow-hidden"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <div className="h-48 overflow-hidden">
                <img 
                  src={gift.image} 
                  alt={gift.name} 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{gift.name}</h3>
                <p className="text-gray-600 mb-4">{gift.description}</p>
                <a 
                  href={gift.link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-block bg-rose-600 text-white py-2 px-4 rounded hover:bg-rose-700 transition"
                >
                  Comprar Presente
                </a>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Seção PIX */}
        <motion.div 
          className="mt-16 bg-rose-50 rounded-xl p-8 max-w-2xl mx-auto text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <h2 className="text-2xl font-serif text-rose-700 mb-4">Contribuição via PIX</h2>
          <p className="mb-6">
            Se preferir, também aceitamos contribuições através de PIX. Basta escanear o código abaixo:
          </p>
          
          <div className="flex justify-center mb-6">
            <div className="bg-white p-4 rounded-lg inline-block">
              <QRCodeSVG 
                value={pixCode} 
                size={180}
                level="H"
                includeMargin={true}
              />
            </div>
          </div>
          
          <div className="bg-white/80 p-4 rounded-lg break-all font-mono text-sm">
            {pixCode}
          </div>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
};

export default Presentes;
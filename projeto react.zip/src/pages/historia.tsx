import Head from 'next/head';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { motion } from 'framer-motion';

// Dados das fotos (pode ser movido para um arquivo JSON se preferir)
const galleryPhotos = [
  { id: 1, src: '/images/historia/1.jpg', alt: 'Primeiro encontro' },
  { id: 2, src: '/images/historia/2.jpg', alt: 'Viagem à praia' },
  { id: 3, src: '/images/historia/3.jpg', alt: 'Aniversário' },
  { id: 4, src: '/images/historia/4.jpg', alt: 'Noivado' },
  { id: 5, src: '/images/historia/5.jpg', alt: 'Festa com amigos' },
  { id: 6, src: '/images/historia/6.jpg', alt: 'Preparativos do casamento' },
];

const Historia = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Head>
        <title>Nossa História - Pedro & Geórgia</title>
      </Head>

      <Header />

      <main className="container mx-auto px-4 py-12 flex-grow">
        <motion.h1 
          className="text-4xl font-serif text-center text-rose-700 mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Nossa História
        </motion.h1>

        <div className="max-w-3xl mx-auto">
          <motion.div 
            className="prose prose-lg text-gray-700"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <p>
              Tudo começou em uma tarde de outono, em 2018, quando nos conhecemos em um café no centro da cidade. 
              Pedro estava lendo seu livro favorito e Geórgia estava estudando para uma prova. 
              Uma xícara de café derramada foi o início de tudo...
            </p>
            <p>
              Desde então, compartilhamos inúmeras aventuras. Viajamos juntos para a praia, montanhas, 
              exploramos novas culinárias e criamos memórias inesquecíveis. 
              Cada momento ao lado do outro foi especial e nos aproximou cada vez mais.
            </p>
            <p>
              Em 2023, durante um jantar romântico sob as estrelas, Pedro surpreendeu Geórgia com um pedido de casamento. 
              Com lágrimas nos olhos e um sorriso no rosto, ela disse "sim" sem hesitar. 
              Agora, estamos contando os dias para o nosso grande dia e mal podemos esperar para compartilhar essa alegria com você.
            </p>
          </motion.div>

          {/* Galeria de Fotos */}
          <motion.h2 
            className="text-2xl font-serif text-rose-700 mt-16 mb-8 text-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            Nossos Momentos
          </motion.h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {galleryPhotos.map((photo, index) => (
              <motion.div
                key={photo.id}
                className="overflow-hidden rounded-lg shadow-md hover:shadow-xl transition-shadow"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5 + (index * 0.1) }}
              >
                <img 
                  src={photo.src} 
                  alt={photo.alt}
                  className="w-full h-64 object-cover transform hover:scale-105 transition-transform duration-500"
                />
              </motion.div>
            ))}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Historia;

// pages/_document.tsx
import { Html, Head, Main, NextScript } from 'next/document';

export default function Document() {
  return (
    <Html lang="pt-BR">
      <Head>
        {/* Google Fonts */}
        https://fonts.googleapis.com/css2?family=Playfair+Display&family=Open+Sans&display=swap
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}

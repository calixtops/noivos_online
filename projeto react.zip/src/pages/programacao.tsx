import Head from 'next/head';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { motion } from 'framer-motion';

const Programacao = () => {
  // Dados da cerimônia e festa
  const events = [
    {
      title: "Cerimônia Religiosa",
      date: "12 de Outubro de 2025",
      time: "15:00",
      location: "Igreja Matriz Nossa Senhora Aparecida",
      address: "Rua das Flores, 123 - Centro, São Paulo/SP",
      mapLink: "https://goo.gl/maps/example"
    },
    {
      title: "Recepção e Festa",
      date: "12 de Outubro de 2025",
      time: "18:00",
      location: "Salão de Eventos Jardim das Rosas",
      address: "Av. das Palmeiras, 456 - Jardim Botânico, São Paulo/SP",
      mapLink: "https://goo.gl/maps/example"
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Head>
        <title>Programação - Pedro & Geórgia</title>
      </Head>

      <Header />

      <main className="container mx-auto px-4 py-12 flex-grow">
        <motion.h1 
          className="text-4xl font-serif text-center text-rose-700 mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Programação do Casamento
        </motion.h1>

        <div className="max-w-4xl mx-auto">
          {/* Lista de Eventos */}
          <div className="space-y-12 mb-16">
            {events.map((event, index) => (
              <motion.div 
                key={index}
                className="bg-white rounded-xl shadow-lg p-8"
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.2 }}
              >
                <h2 className="text-2xl font-serif text-rose-600 mb-4">{event.title}</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <h3 className="text-gray-500">Data</h3>
                    <p className="text-lg font-medium">{event.date}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-gray-500">Horário</h3>
                    <p className="text-lg font-medium">{event.time}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-gray-500">Local</h3>
                    <p className="text-lg font-medium">{event.location}</p>
                  </div>
                </div>
                
                <p className="mt-4 text-gray-700">
                  <span className="font-medium">Endereço:</span> {event.address}
                </p>
                
                <div className="mt-6">
                  <a 
                    href={event.mapLink} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-rose-600 hover:text-rose-800"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                    </svg>
                    Ver no Mapa
                  </a>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Mapa com local principal */}
          <motion.div
            className="bg-white rounded-xl shadow-lg overflow-hidden"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <h2 className="text-2xl font-serif text-rose-700 p-6 pb-0">Local da Cerimônia e Festa</h2>
            <div className="h-96 w-full mt-4">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.097825376838!2d-46.65390548502178!3d-23.56518418468069!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce59c8da0aa315%3A0xd59f9431f2c9776a!2sAv.%20Paulista%2C%20S%C3%A3o%20Paulo%20-%20SP!5e0!3m2!1spt-BR!2sbr!4v1623868385748!5m2!1spt-BR!2sbr" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
              ></iframe>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Programacao;